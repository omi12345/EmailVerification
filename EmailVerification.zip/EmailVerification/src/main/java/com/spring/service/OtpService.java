package com.spring.service;

import java.time.LocalDateTime;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.spring.enitity.Otp;
import com.spring.repository.OtpRepository;

@Service
public class OtpService {
    @Autowired
    private OtpRepository otpRepository;

    @Autowired
    private JavaMailSender mailSender;

    private static final int EXPIRATION_TIME_MINUTES = 2;

    public String generateOtp(String email) {
        String otp = String.valueOf(new Random().nextInt(999999));
        LocalDateTime expirationTime = LocalDateTime.now().plusMinutes(EXPIRATION_TIME_MINUTES);

        Otp otpEntity = new Otp();
        otpEntity.setEmail(email);
        otpEntity.setOtp(otp);
        otpEntity.setExpirationTime(expirationTime);

        otpRepository.save(otpEntity);

        sendOtpEmail(email, otp);

        return otp;
    }

    public boolean verifyOtp(String email, String otp) {
        Otp otpEntity = otpRepository.findByEmailAndOtp(email, otp);
        if (otpEntity != null && otpEntity.getExpirationTime().isAfter(LocalDateTime.now())) {
            otpRepository.delete(otpEntity);
            return true;
        }
        return false;
    }

    private void sendOtpEmail(String email, String otp) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(email);
        message.setSubject("Your OTP Code");
        message.setText("Your OTP code is " + otp);
        mailSender.send(message);
    }
}