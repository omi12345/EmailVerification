package com.spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.spring.service.OtpService;

@Controller
@RequestMapping("/otp")
public class OtpController {
    @Autowired
    private OtpService otpService;

    @GetMapping("/home")
    @ResponseBody
    public String showHome()
    {
    	return "This is home page";
    }
    
    @GetMapping("/request")
    public String showOtpRequestForm(Model model) {
        model.addAttribute("email", new String());
        return "otp_request";
    }

    @PostMapping("/request")
    public String requestOtp(@RequestParam("email") String email, Model model) {
        otpService.generateOtp(email);
        model.addAttribute("email", email);
        return "otp_verify";
    }

    @PostMapping("/verify")
    public String verifyOtp(@RequestParam("email") String email, @RequestParam("otp") String otp, Model model) {
        if (otpService.verifyOtp(email, otp)) {
            model.addAttribute("message", "OTP verified successfully.");
        } else {
            model.addAttribute("message", "Invalid or expired OTP.");
        }
        return "otp_result";
    }
}
